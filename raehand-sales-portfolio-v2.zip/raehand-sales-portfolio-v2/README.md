# Raehand Riviand Maleteng — Personal Sales Portfolio V2

Redesign total berdasarkan website referensi `https://raehandriviandmaleteng.netlify.app/` dan arahan redesign di percakapan.

## Data yang dipakai sebagai patokan
- Name: Raehand Riviand Maleteng
- Role: Sales Officer | Sales & Marketing
- Achievement: 6 unit rumah KPR terealisasi; website referensi menampilkan badge TOP SALES
- Experience: PT Bank Rakyat Indonesia — Sales Officer — Mulai 2024
- Freelance: jual beli HP second; perbaikan handphone; gantungan kunci custom
- Education: SMA Negeri 1 Kotamobagu — IPS — 2021–2024
- Phone / WhatsApp: 0895806296605
- Email: raehand28@gmail.com
- Instagram: @Skreand
- TikTok: @Skrean28
- Location: Kotamobagu, Indonesia

## Deploy ke Netlify
Upload isi folder ini sebagai site directory. `index.html` sudah menjadi entry point.
