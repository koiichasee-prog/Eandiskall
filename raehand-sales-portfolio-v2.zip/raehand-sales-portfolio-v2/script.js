const menuToggle=document.getElementById('menuToggle');
const navLinks=document.getElementById('navLinks');
const backtop=document.getElementById('backtop');
const toast=document.getElementById('toast');

menuToggle?.addEventListener('click',()=>{
  const open=navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded',String(open));
});

document.querySelectorAll('.nav-links a').forEach(a=>a.addEventListener('click',()=>{
  navLinks.classList.remove('open');
  menuToggle?.setAttribute('aria-expanded','false');
}));

const revealObserver=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');revealObserver.unobserve(e.target)}})
},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));

const sections=[...document.querySelectorAll('main section[id]')];
const navAnchors=[...document.querySelectorAll('.nav-links a[href^="#"]')];
const sectionObserver=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){
      navAnchors.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+entry.target.id));
    }
  })
},{rootMargin:'-38% 0px -50% 0px',threshold:0});
sections.forEach(s=>sectionObserver.observe(s));

window.addEventListener('scroll',()=>{backtop.classList.toggle('show',window.scrollY>750)},{passive:true});
backtop.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));

function showToast(msg){toast.textContent=msg;toast.classList.add('show');clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(()=>toast.classList.remove('show'),1800)}

document.querySelectorAll('[data-copy]').forEach(btn=>btn.addEventListener('click',async()=>{
  try{await navigator.clipboard.writeText(btn.dataset.copy);showToast('Nomor WhatsApp disalin.')}catch{showToast('Salin nomor: '+btn.dataset.copy)}
}));
