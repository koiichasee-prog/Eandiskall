# Raehand Riviand Maleteng — Sales Portfolio V5

Portfolio personal dengan pendekatan recruiter-first, multi-language, dan theme system yang stabil.

## Fitur
- Responsive desktop / tablet / mobile
- Bahasa Indonesia, English, 日本語
- Preferensi bahasa tersimpan di browser
- Light mode / Dark mode
- Preferensi tema tersimpan di browser
- Theme bootstrap sebelum stylesheet untuk mengurangi flash saat load
- Scroll progress indicator
- Active section navigation + `aria-current`
- Reveal-on-scroll dengan fallback jika IntersectionObserver tidak tersedia
- Reduced-motion support
- Mobile menu dengan Escape, click-outside, dan ARIA state
- WhatsApp CTA dengan pesan sesuai bahasa aktif
- Copy WhatsApp dengan Clipboard API + fallback textarea
- Download CV
- SEO metadata + Open Graph + Schema.org Person
- Mobile header diperketat agar tidak overflow pada layar sempit

## Perbaikan V5
- Menghapus duplikasi blok responsive CSS.
- Menghindari crash ketika API browser tertentu tidak tersedia.
- Memperbaiki penyimpanan `localStorage` agar aman ketika storage diblokir.
- Memperbaiki aksesibilitas language switcher, theme switcher, mobile menu, dan copy button.
- Menutup mobile menu setelah navigasi, Escape, dan klik di luar menu.
- Mengubah link WhatsApp berdasarkan bahasa yang sedang dipilih.
- Memperbarui `theme-color` browser saat tema berubah.
- Memperbarui title dan Open Graph metadata ketika bahasa berubah.
- Memperbaiki indikator navigasi aktif.
- Mengurangi risiko layout overflow pada layar sekitar 320px.

## Struktur
- `index.html` — halaman utama
- `style.css` — visual system dan responsive layout
- `script.js` — interaksi, i18n, theme system
- `assets/profile.webp` — foto profil
- `CV-Raehand-Riviand-Maleteng.pdf` — CV
- `_headers` — header Netlify
- `robots.txt` / `sitemap.xml` — SEO dasar

## Data
Angka pencapaian hanya menggunakan data yang tersedia pada portfolio. Jangan menambahkan omzet, conversion rate, target, atau angka lain tanpa bukti.


## V6 FIX
- Fixed incomplete language switching across visible portfolio content.
- Added Japanese/English/Indonesian labels for business cards and accessibility controls.
- Hardened dark-mode contrast for strong panels, case study, navigation, buttons, profile data, and contact areas.
- Added language/theme state attributes for easier maintenance.
