const $=(s,root=document)=>root.querySelector(s);
const $$=(s,root=document)=>[...root.querySelectorAll(s)];

const menu=$('#menu'), nav=$('#navLinks'), progress=$('#progress'), back=$('#backtop'), toast=$('#toast'), themeBtn=$('#themeBtn'), themeIcon=$('#themeIcon');
const root=document.documentElement;

function storageGet(key,fallback=''){
  try{return localStorage.getItem(key) || fallback}catch{return fallback}
}
function storageSet(key,value){
  try{localStorage.setItem(key,value)}catch{}
}
function showToast(message){
  if(!toast)return;
  toast.textContent=message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer=setTimeout(()=>toast.classList.remove('show'),2200);
}

function closeMenu(){
  nav?.classList.remove('open');
  menu?.setAttribute('aria-expanded','false');
  if(typeof currentLang!=='undefined') menu?.setAttribute('aria-label',currentLang==='ja'?'ナビゲーションを開く':currentLang==='en'?'Open navigation':'Buka navigasi');
}
function toggleMenu(){
  if(!nav || !menu)return;
  const open=nav.classList.toggle('open');
  menu.setAttribute('aria-expanded',String(open));
  menu.setAttribute('aria-label',open?(currentLang==='ja'?'ナビゲーションを閉じる':currentLang==='en'?'Close navigation':'Tutup navigasi'):(currentLang==='ja'?'ナビゲーションを開く':currentLang==='en'?'Open navigation':'Buka navigasi'));
}
menu?.addEventListener('click',toggleMenu);
$$('.nav nav a').forEach(a=>a.addEventListener('click',closeMenu));
document.addEventListener('click',e=>{
  if(nav?.classList.contains('open') && !nav.contains(e.target) && !menu?.contains(e.target) && !e.target.closest('.site-tools')) closeMenu();
});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});

// Reveal animation — gracefully falls back when IntersectionObserver is unavailable.
if('IntersectionObserver' in window){
  const observer=new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting){e.target.classList.add('in');observer.unobserve(e.target)}
    });
  },{threshold:.12});
  $$('.reveal').forEach(el=>observer.observe(el));
}else{$$('.reveal').forEach(el=>el.classList.add('in'))}

let ticking=false;
function updateScrollUI(){
  const h=document.documentElement.scrollHeight-window.innerHeight;
  if(progress)progress.style.width=(h>0?(window.scrollY/h)*100:0)+'%';
  back?.classList.toggle('show',window.scrollY>700);
  ticking=false;
}
window.addEventListener('scroll',()=>{
  if(!ticking){window.requestAnimationFrame(updateScrollUI);ticking=true}
},{passive:true});
updateScrollUI();
back?.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));

// Contact actions.
$('#copyBtn')?.addEventListener('click',async e=>{
  const value=e.currentTarget.dataset.copy || '+62895806296605';
  const success={id:'Nomor WhatsApp disalin.',en:'WhatsApp number copied.',ja:'WhatsApp番号をコピーしました.'};
  try{
    if(navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(value);
    else{
      const input=document.createElement('textarea'); input.value=value; input.setAttribute('readonly',''); input.style.position='fixed'; input.style.opacity='0'; document.body.appendChild(input); input.select(); document.execCommand('copy'); input.remove();
    }
    showToast(success[currentLang]||success.id);
  }catch{showToast(currentLang==='ja'?'コピーに失敗しました':currentLang==='en'?'Copy failed.':'Gagal menyalin nomor.');}
});

// Theme system. The head script sets the initial value early to avoid a flash.
function setTheme(theme,save=true){
  const value=theme==='dark'?'dark':'light';
  root.dataset.theme=value;
  if(save)storageSet('raehand-theme',value);
  const dark=value==='dark';
  if(themeIcon)themeIcon.textContent=dark?'☀':'☾';
  if(themeBtn){
    const label=dark?(currentLang==='ja'?'ライトモードに切替':currentLang==='en'?'Use light mode':'Gunakan mode terang'):(currentLang==='ja'?'ダークモードに切替':currentLang==='en'?'Use dark mode':'Gunakan mode gelap');
    themeBtn.setAttribute('aria-label',label);themeBtn.title=label;
  }
  const meta=$('meta[name="theme-color"]'); if(meta)meta.content=dark?'#0d0d0c':'#f5f3ef';
}
let currentLang=storageGet('raehand-lang','id');
const savedTheme=storageGet('raehand-theme','');
const preferred=window.matchMedia?.('(prefers-color-scheme: dark)').matches;
setTheme(savedTheme || (preferred?'dark':'light'),false);
themeBtn?.addEventListener('click',()=>setTheme(root.dataset.theme==='dark'?'light':'dark'));

const translations={
 id:{
  title:'Raehand Riviand Maleteng — Sales Portfolio',
  desc:'Portfolio profesional Raehand Riviand Maleteng — Sales Officer dengan pengalaman penjualan, komunikasi pelanggan, follow-up, dan 6 unit rumah KPR terealisasi.',
  nav:['Dampak','Pengalaman','Metode','Bisnis','Mari bicara ↗'],
  eyebrow:'TERBUKA UNTUK PELUANG • KOTAMOBAGU, ID', role:'SALES OFFICER / SALES & MARKETING',
  hero:'Sales yang<br><span>mendengar.</span><br>Menjual dengan tujuan.',
  lead:'Saya membantu calon pelanggan memahami pilihan, membangun kepercayaan, dan menjaga proses tetap bergerak sampai keputusan.',
  wa:'WhatsApp ↗', cv:'Download CV ↓', meta:['PORTFOLIO SALES PERSONAL','2026'],
  ticker:['SALES & MARKETING','CUSTOMER RELATIONSHIP','KOMUNIKASI','FOLLOW-UP','BERORIENTASI HASIL'],
  profileLabel:'01 / PROFIL', roleCard:'PERAN', proven:'HASIL TERBUKTI', units:'UNIT RUMAH KPR<br>TEREALISASI',
  impactLabel:'02 / DAMPAK', impactTitle:'Jangan hanya<br><i>percaya kata-kata.</i>', impactNote:'Satu hasil utama menjadi anchor portfolio. Detail proses menjelaskan kemampuan di balik angka tersebut.',
  salesResult:'HASIL PENJUALAN', resultLabel:'UNIT RUMAH KPR<br><strong>TEREALISASI</strong>', stamp:'HASIL<br>TERBUKTI',
  proofLead:'Pengalaman sales bukan hanya tentang berbicara. <strong>Hasil datang dari proses yang konsisten.</strong>',
  proof:[['Need discovery','Memahami kebutuhan dan pertimbangan calon nasabah sebelum menawarkan solusi.'],['Komunikasi jelas','Menjelaskan produk atau layanan dengan bahasa yang mudah dipahami.'],['Follow-up','Menjaga komunikasi, menjawab pertimbangan, dan mendampingi proses.'],['Fokus closing','Menggerakkan proses menuju keputusan dan realisasi.']],
  disclaimer:'Angka ditampilkan berdasarkan data portfolio yang tersedia. Tidak ada conversion rate, omzet, atau target yang dibuat-buat.',
  expLabel:'03 / PENGALAMAN', expTitle:'Pengalaman yang<br><i>membentuk cara kerja.</i>', expNote:'Dari lingkungan perbankan hingga usaha mandiri: menjual, melayani, dan menyelesaikan kebutuhan.',
  expDate:'JUNI 2024—MEI 2026', expType:'PENGALAMAN PROFESIONAL', expRole:'Sales Officer', expDesc:'Melaksanakan kegiatan penjualan dan pemasaran produk, berkomunikasi dengan calon nasabah dan nasabah, menjelaskan produk dan layanan, membantu pencapaian target, serta menjaga hubungan dengan nasabah.',
  tags:['Sales & Marketing','Customer Communication','Follow-up','Target Oriented'], core:'PENGALAMAN<br>UTAMA', independent:'MANDIRI / FREELANCE', businessService:'Bisnis & Customer Service', independentDesc:'Pengalaman mandiri melalui jual beli HP second, perbaikan handphone, dan produk custom. Aktivitas ini melatih penawaran, komunikasi pelanggan, layanan, dan problem solving.', explore:'Lihat pengalaman bisnis ↗',
  methodLabel:'04 / METODE', methodTitle:'Empat langkah.<br><i>Satu arah: closing.</i>', methodNote:'Kerangka kerja sederhana yang membuat aktivitas sales terukur secara proses, bukan hanya hasil akhir.', methods:[['Prospect','Menemukan dan membuka percakapan dengan calon pelanggan.'],['Understand','Menggali kebutuhan, kondisi, dan pertimbangan pelanggan.'],['Follow-up','Menjaga momentum komunikasi dan membantu proses keputusan.'],['Close','Mengarahkan proses menuju keputusan dan realisasi penjualan.']],
  caseLabel:'05 / STUDI KASUS', caseTag:'PENJUALAN KPR', caseTitle:'6 unit bukan<br><i>sekadar angka.</i>', caseDesc:'Angka tersebut diposisikan sebagai hasil akhir dari rangkaian aktivitas: memahami kebutuhan → menjelaskan produk → follow-up → membantu keputusan → realisasi.', caseSteps:[['Understand','Kebutuhan & pertimbangan'],['Explain','Produk & value'],['Follow-up','Komunikasi berkelanjutan'],['Realise','Keputusan & realisasi']], caseUnits:'UNIT<br>KPR',
  bizLabel:'06 / PENGALAMAN BISNIS', bizTitle:'Belajar menjual<br><i>dari pasar nyata.</i>', bizNote:'Aktivitas mandiri memperkuat kemampuan melihat kebutuhan, menawarkan solusi, dan memberikan layanan.', biz:[['SELLING','Jual Beli<br>HP Second','Menawarkan unit, menjawab pertanyaan, berkomunikasi dengan calon pembeli, dan mengarahkan transaksi.'],['SERVICE','Perbaikan<br>Handphone','Menangani kebutuhan pelanggan melalui layanan perbaikan dan komunikasi mengenai solusi.'],['PRODUCT','Gantungan Kunci<br>Custom','Melayani produk berdasarkan permintaan dan mengelola komunikasi dengan pelanggan.']],
  capLabel:'07 / KEMAMPUAN', capTitle:'Skill yang<br><i>siap dipakai.</i>', capNote:'Disusun berdasarkan kemampuan yang benar-benar tersedia dalam data portfolio, bukan daftar skill yang dibesar-besarkan.', skills:[['Sales &<br>Marketing','Penawaran produk, komunikasi value, dan orientasi terhadap target.'],['Communication','Komunikasi dengan calon nasabah dan pelanggan.'],['Customer Relationship','Menjaga hubungan dan komunikasi setelah interaksi awal.'],['Follow-up','Menjaga proses tetap bergerak menuju keputusan.'],['Microsoft Office','Pemahaman dasar Microsoft Office.'],['Learning Agility','Terbuka untuk belajar dan berkembang dalam lingkungan kerja profesional.']],
  profLabel:'08 / PROFIL', profTitle:'Profesional<br><i>di balik portfolio.</i>', profile:[['NAMA','Raehand Riviand Maleteng'],['PENDIDIKAN','SMA Negeri 1 Kotamobagu<br><small>IPS · 2021—2024</small>'],['LOKASI','Kotamobagu, Indonesia'],['FOKUS','Sales · Customer Relationship · Communication']],
  contactLabel:'09 / KONTAK', contactTitle:'Kalau yang dicari<br><i>bukan sekadar CV.</i>', contactDesc:'Hubungi saya untuk peluang kerja, kolaborasi, atau posisi yang membutuhkan kemampuan sales, komunikasi, follow-up, dan customer relationship.', start:'Mulai percakapan ↗', contactCV:'Download CV ↓', email:'EMAIL', phone:'TELEPON / WHATSAPP', copy:'SALIN WHATSAPP', instagram:'INSTAGRAM', copyText:'0895806296605', footer:'PORTFOLIO SALES · 2026', back:'KEMBALI KE ATAS ↑'
 },
 en:{
  title:'Raehand Riviand Maleteng — Sales Portfolio', desc:'Professional portfolio of Raehand Riviand Maleteng — Sales Officer focused on sales, customer communication, follow-up, and 6 realized KPR home units.', nav:['Impact','Experience','Method','Business','Let’s talk ↗'], eyebrow:'OPEN TO OPPORTUNITIES • KOTAMOBAGU, ID', role:'SALES OFFICER / SALES & MARKETING', hero:'Sales that<br><span>listens.</span><br>Sells with purpose.', lead:'I help prospects understand their options, build trust, and keep the process moving toward a decision.', wa:'WhatsApp ↗', cv:'Download CV ↓', meta:['PERSONAL SALES PORTFOLIO','2026'], ticker:['SALES & MARKETING','CUSTOMER RELATIONSHIP','COMMUNICATION','FOLLOW-UP','RESULT ORIENTED'], profileLabel:'01 / PROFILE', roleCard:'ROLE', proven:'PROVEN RESULT', units:'KPR HOME UNITS<br>REALIZED', impactLabel:'02 / IMPACT', impactTitle:'Don’t just<br><i>take my word for it.</i>', impactNote:'One primary result anchors the portfolio. The process behind it shows the capabilities that produced it.', salesResult:'SALES RESULT', resultLabel:'KPR HOME UNITS<br><strong>REALIZED</strong>', stamp:'PROVEN<br>RESULT', proofLead:'Sales is not only about talking. <strong>Results come from consistent process.</strong>', proof:[['Need discovery','Understanding customer needs and considerations before presenting a solution.'],['Clear communication','Explaining products or services in an easy-to-understand way.'],['Follow-up','Maintaining communication, answering concerns, and supporting the process.'],['Closing focus','Moving the process toward a decision and realization.']], disclaimer:'Figures are based on the portfolio data available. No conversion rate, revenue, or target figures have been fabricated.', expLabel:'03 / EXPERIENCE', expTitle:'Experience that<br><i>shapes the way I work.</i>', expNote:'From banking to independent business: selling, serving, and solving customer needs.', expDate:'JUNE 2024—MAY 2026', expType:'PROFESSIONAL EXPERIENCE', expRole:'Sales Officer', expDesc:'Handled sales and marketing activities, communicated with prospects and customers, explained products and services, supported target achievement, and maintained customer relationships.', tags:['Sales & Marketing','Customer Communication','Follow-up','Target Oriented'], core:'CORE<br>EXPERIENCE', independent:'INDEPENDENT / FREELANCE', businessService:'Business & Customer Service', independentDesc:'Independent experience through used-phone trading, phone repair, and custom products. These activities strengthened selling, customer communication, service, and problem-solving skills.', explore:'Explore business work ↗', methodLabel:'04 / METHOD', methodTitle:'Four steps.<br><i>One direction: closing.</i>', methodNote:'A simple framework that makes sales activity measurable through process, not only the final result.', methods:[['Prospect','Finding and opening conversations with potential customers.'],['Understand','Exploring customer needs, context, and considerations.'],['Follow-up','Maintaining communication momentum and supporting decisions.'],['Close','Moving the process toward a decision and realized sale.']], caseLabel:'05 / CASE STUDY', caseTag:'KPR SALES', caseTitle:'6 units are not<br><i>just a number.</i>', caseDesc:'The figure represents the end result of a sequence: understand needs → explain the product → follow up → support the decision → realization.', caseSteps:[['Understand','Needs & considerations'],['Explain','Product & value'],['Follow-up','Ongoing communication'],['Realise','Decision & realization']], caseUnits:'KPR<br>UNITS', bizLabel:'06 / BUSINESS WORK', bizTitle:'Learning to sell<br><i>in the real market.</i>', bizNote:'Independent activities strengthened my ability to identify needs, offer solutions, and provide service.', biz:[['SELLING','Used Phone<br>Trading','Offering units, answering questions, communicating with prospects, and guiding transactions.'],['SERVICE','Phone<br>Repair','Handling customer needs through repair services and solution-focused communication.'],['PRODUCT','Custom Keychain<br>Products','Serving made-to-order products and managing customer communication.']], capLabel:'07 / CAPABILITIES', capTitle:'Skills that are<br><i>ready to use.</i>', capNote:'Based on capabilities actually supported by the portfolio data, rather than an inflated skill list.', skills:[['Sales &<br>Marketing','Product offering, value communication, and target orientation.'],['Communication','Communication with prospects and customers.'],['Customer Relationship','Maintaining relationships and communication after the initial interaction.'],['Follow-up','Keeping the process moving toward a decision.'],['Microsoft Office','Basic Microsoft Office proficiency.'],['Learning Agility','Open to learning and growing in a professional environment.']], profLabel:'08 / PROFILE', profTitle:'The professional<br><i>behind the portfolio.</i>', profile:[['NAME','Raehand Riviand Maleteng'],['EDUCATION','SMA Negeri 1 Kotamobagu<br><small>Social Sciences · 2021—2024</small>'],['LOCATION','Kotamobagu, Indonesia'],['FOCUS','Sales · Customer Relationship · Communication']], contactLabel:'09 / CONTACT', contactTitle:'If you are looking for<br><i>more than a CV.</i>', contactDesc:'Contact me for job opportunities, collaborations, or roles requiring sales, communication, follow-up, and customer relationship skills.', start:'Start a conversation ↗', contactCV:'Download CV ↓', email:'EMAIL', phone:'PHONE / WHATSAPP', copy:'COPY WHATSAPP', instagram:'INSTAGRAM', copyText:'0895806296605', footer:'SALES PORTFOLIO · 2026', back:'BACK TO TOP ↑'
 },
 ja:{
  title:'Raehand Riviand Maleteng — Sales Portfolio', desc:'Raehand Riviand Maletengのポートフォリオ。営業、顧客コミュニケーション、フォローアップ、KPR住宅6件の実績を紹介します。', nav:['実績','経験','方法','ビジネス','お問い合わせ ↗'], eyebrow:'採用機会を歓迎 • KOTAMOBAGU, ID', role:'SALES OFFICER / SALES & MARKETING', hero:'話を<br><span>聴く。</span><br>目的を持って売る。', lead:'お客様の選択肢を分かりやすく伝え、信頼を築き、意思決定までプロセスを前に進めます。', wa:'WhatsApp ↗', cv:'履歴書をダウンロード ↓', meta:['SALES PORTFOLIO','2026'], ticker:['SALES & MARKETING','CUSTOMER RELATIONSHIP','コミュニケーション','FOLLOW-UP','成果重視'], profileLabel:'01 / プロフィール', roleCard:'役割', proven:'実績', units:'KPR住宅<br>成約・実現', impactLabel:'02 / 実績', impactTitle:'言葉だけでなく<br><i>実績で伝える。</i>', impactNote:'主要な実績をポートフォリオの軸にし、その数字を生み出したプロセスを示します。', salesResult:'営業実績', resultLabel:'KPR住宅<br><strong>実現</strong>', stamp:'実績<br>PROVEN', proofLead:'営業は話すだけではありません。<strong>成果は継続したプロセスから生まれます。</strong>', proof:[['ニーズ把握','提案前に、お客様のニーズや検討事項を理解します。'],['分かりやすい説明','商品やサービスを理解しやすい言葉で説明します。'],['フォローアップ','継続的に連絡し、疑問や検討事項をサポートします。'],['クロージング','意思決定と成約に向けてプロセスを進めます。']], disclaimer:'数値は提供されたポートフォリオデータに基づいています。存在しない成約率、売上、目標値は掲載していません。', expLabel:'03 / 経験', expTitle:'仕事の進め方を<br><i>形作った経験。</i>', expNote:'銀行での経験から個人ビジネスまで。販売、顧客対応、課題解決に取り組みました。', expDate:'2024年6月—2026年5月', expType:'PROFESSIONAL EXPERIENCE', expRole:'Sales Officer', expDesc:'商品の販売・マーケティング、見込み顧客や顧客とのコミュニケーション、商品・サービスの説明、目標達成のサポート、顧客関係の維持を担当しました。', tags:['Sales & Marketing','顧客コミュニケーション','Follow-up','目標志向'], core:'主要<br>経験', independent:'INDEPENDENT / FREELANCE', businessService:'ビジネス & 顧客サービス', independentDesc:'中古スマートフォン販売、修理、カスタム商品の経験を通じて、提案、顧客対応、サービス、問題解決を実践しました。', explore:'ビジネス経験を見る ↗', methodLabel:'04 / METHOD', methodTitle:'4つのステップ。<br><i>方向は一つ：成約。</i>', methodNote:'最終結果だけでなく、営業プロセスそのものを整理して行動します。', methods:[['Prospect','見込み顧客を見つけ、会話を始めます。'],['Understand','ニーズ、状況、検討事項を把握します。'],['Follow-up','コミュニケーションを継続し、意思決定を支援します。'],['Close','意思決定と成約に向けて進めます。']], caseLabel:'05 / CASE STUDY', caseTag:'KPR SALES', caseTitle:'6件は<br><i>ただの数字ではない。</i>', caseDesc:'ニーズ把握 → 商品説明 → フォローアップ → 意思決定支援 → 実現、という一連の活動の結果です。', caseSteps:[['Understand','ニーズと検討事項'],['Explain','商品と価値'],['Follow-up','継続的な連絡'],['Realise','意思決定と実現']], caseUnits:'KPR<br>住宅', bizLabel:'06 / BUSINESS WORK', bizTitle:'リアルな市場で<br><i>販売を学ぶ。</i>', bizNote:'個人での活動を通じて、ニーズを見つけ、解決策を提案し、サービスを提供する力を磨きました。', biz:[['SELLING','中古スマートフォン<br>販売','商品を提案し、質問に答え、購入希望者とコミュニケーションを取り、取引を進めます。'],['SERVICE','スマートフォン<br>修理','修理サービスと解決策の説明を通じて顧客ニーズに対応します。'],['PRODUCT','カスタム<br>キーホルダー','オーダー商品に対応し、顧客とのコミュニケーションを管理します。']], capLabel:'07 / CAPABILITIES', capTitle:'すぐに活かせる<br><i>スキル。</i>', capNote:'実際のポートフォリオデータで裏付けられる能力を中心に掲載しています。', skills:[['Sales &<br>Marketing','商品提案、価値の説明、目標志向。'],['Communication','見込み顧客・顧客とのコミュニケーション。'],['Customer Relationship','初回接点後の関係構築とコミュニケーション。'],['Follow-up','意思決定までプロセスを継続します。'],['Microsoft Office','Microsoft Officeの基礎知識。'],['Learning Agility','専門的な環境で学び、成長する姿勢。']], profLabel:'08 / PROFILE', profTitle:'ポートフォリオの<br><i>背景にいる人。</i>', profile:[['名前','Raehand Riviand Maleteng'],['学歴','SMA Negeri 1 Kotamobagu<br><small>社会科学 · 2021—2024</small>'],['所在地','Kotamobagu, Indonesia'],['専門','Sales · Customer Relationship · Communication']], contactLabel:'09 / CONTACT', contactTitle:'履歴書だけでは<br><i>伝わらない部分を。</i>', contactDesc:'営業、コミュニケーション、フォローアップ、顧客関係のスキルを必要とする仕事や協業について、お気軽にご連絡ください。', start:'お問い合わせする ↗', contactCV:'履歴書をダウンロード ↓', email:'EMAIL', phone:'電話 / WHATSAPP', copy:'WHATSAPPをコピー', instagram:'INSTAGRAM', copyText:'0895806296605', footer:'SALES PORTFOLIO · 2026', back:'トップへ戻る ↑'
 }
};


const whatsappMessages={
  id:'Halo Kak Raehand, saya ingin menghubungi Anda.',
  en:'Hello Raehand, I would like to contact you.',
  ja:'こんにちはRaehandさん、お問い合わせしたくご連絡しました。'
};
Object.keys(translations).forEach(lang=>{
  translations[lang].waHref='https://wa.me/62895806296605?text='+encodeURIComponent(whatsappMessages[lang]||whatsappMessages.id);
});

function applyLanguage(lang,{persist=true,close=true}={}){
  const t=translations[lang]||translations.id;
  currentLang=translations[lang]?lang:'id';
  if(persist)storageSet('raehand-lang',currentLang);
  root.lang=currentLang==='ja'?'ja':currentLang;
  document.title=t.title;
  const desc=$('meta[name="description"]');if(desc)desc.content=t.desc;
  const ogTitle=$('meta[property="og:title"]');if(ogTitle)ogTitle.content=t.title;
  const ogDesc=$('meta[property="og:description"]');if(ogDesc)ogDesc.content=t.desc;

  const navText=$$('.nav nav a');navText.forEach((el,i)=>{if(t.nav[i]){if(i===4){const parts=t.nav[i].replace(/\s*↗\s*$/,'');el.innerHTML=parts+' <b>↗</b>';}else el.textContent=t.nav[i]}});
  const aria={id:{nav:'Navigasi utama',lang:'Pilih bahasa',menu:'Buka navigasi',close:'Tutup navigasi',copy:'Salin nomor WhatsApp',ticker:'Keahlian utama'},en:{nav:'Main navigation',lang:'Language selector',menu:'Open navigation',close:'Close navigation',copy:'Copy WhatsApp number',ticker:'Core skills'},ja:{nav:'メインナビゲーション',lang:'言語選択',menu:'ナビゲーションを開く',close:'ナビゲーションを閉じる',copy:'WhatsApp番号をコピー',ticker:'主なスキル'}}[currentLang];
  $('#navLinks')?.setAttribute('aria-label',aria.nav);$('.lang-switch')?.setAttribute('aria-label',aria.lang);menu?.setAttribute('aria-label',nav?.classList.contains('open')?aria.close:aria.menu);$('#copyBtn')?.setAttribute('aria-label',aria.copy);$('.ticker')?.setAttribute('aria-label',aria.ticker);
  $('.eyebrow')?.replaceChildren(Object.assign(document.createElement('span'),{className:'status'}));
  const eyebrow=$('.eyebrow');if(eyebrow)eyebrow.insertAdjacentText('beforeend',' '+t.eyebrow);
  $('.role')?.replaceChildren(document.createTextNode(t.role));
  const hero=$('.hero h1');if(hero)hero.innerHTML=t.hero;
  const lead=$('.hero-lead');if(lead)lead.textContent=t.lead;
  const wa=$('.btn.primary');if(wa){wa.innerHTML=t.wa.replace(/\s*↗\s*$/,'')+' <span>↗</span>';wa.href=t.waHref}
  const cv=$('.btn.secondary');if(cv)cv.innerHTML=t.cv+' <span>↓</span>';
  $$('.hero-meta span').forEach((el,i)=>{if(t.meta[i])el.textContent=t.meta[i]});
  $$('.ticker-track span').forEach((el,i)=>el.textContent=t.ticker[i%t.ticker.length]);
  $('.visual-head span:first-child')?.replaceChildren(document.createTextNode(t.profileLabel));
  $('.floating.top small')?.replaceChildren(document.createTextNode(t.roleCard));
  $('.floating.bottom small')?.replaceChildren(document.createTextNode(t.proven));
  const units=$('.floating.bottom b');if(units)units.innerHTML=t.units;

  $('.impact .index')?.replaceChildren(document.createTextNode(t.impactLabel));
  $('.impact .section-top h2')?.replaceChildren();if($('.impact .section-top h2'))$('.impact .section-top h2').innerHTML=t.impactTitle;
  $('.impact .section-note')?.replaceChildren(document.createTextNode(t.impactNote));
  $('.impact-number .split span:first-child')?.replaceChildren(document.createTextNode(t.salesResult));
  const numberLabel=$('.number-label');if(numberLabel)numberLabel.innerHTML=t.resultLabel;
  const stamp=$('.stamp');if(stamp)stamp.innerHTML=t.stamp;
  const proofLead=$('.proof-lead');if(proofLead)proofLead.innerHTML=t.proofLead;
  $$('.proof-list>div').forEach((el,i)=>{if(!t.proof[i])return;el.querySelector('b').textContent=t.proof[i][0];el.querySelector('p').textContent=t.proof[i][1]});
  $('.disclaimer')?.replaceChildren(document.createTextNode(t.disclaimer));

  $('.experience .index')?.replaceChildren(document.createTextNode(t.expLabel));
  const expH=$('.experience .section-top h2');if(expH)expH.innerHTML=t.expTitle;
  $('.experience .section-note')?.replaceChildren(document.createTextNode(t.expNote));
  $('.exp-date strong')?.replaceChildren(document.createTextNode(t.expDate));$('.exp-date span')?.replaceChildren(document.createTextNode(t.expType));
  $('.exp-main h3')?.replaceChildren(document.createTextNode(t.expRole));$('.exp-main>p:not(.mono)')?.replaceChildren(document.createTextNode(t.expDesc));
  $$('.tags span').forEach((el,i)=>{if(t.tags[i])el.textContent=t.tags[i]});
  const core=$('.exp-side p');if(core)core.innerHTML=t.core;
  $('.independent>div:first-child .mono')?.replaceChildren(document.createTextNode(t.independent));$('.independent h3')?.replaceChildren(document.createTextNode(t.businessService));$('.independent>p')?.replaceChildren(document.createTextNode(t.independentDesc));$('.independent>a')?.replaceChildren(document.createTextNode(t.explore));

  $('.method .index')?.replaceChildren(document.createTextNode(t.methodLabel));const methodH=$('.method .section-top h2');if(methodH)methodH.innerHTML=t.methodTitle;$('.method .section-note')?.replaceChildren(document.createTextNode(t.methodNote));
  $$('.method-grid article').forEach((el,i)=>{if(!t.methods[i])return;el.querySelector('h3').textContent=t.methods[i][0];el.querySelector('p').textContent=t.methods[i][1]});

  $('.case .index')?.replaceChildren(document.createTextNode(t.caseLabel));$('.case-tag')?.replaceChildren(document.createTextNode(t.caseTag));const caseH=$('.case-copy h2');if(caseH)caseH.innerHTML=t.caseTitle;$('.case-copy>p:last-child')?.replaceChildren(document.createTextNode(t.caseDesc));
  $$('.case-step').forEach((el,i)=>{if(!t.caseSteps[i])return;el.querySelector('b').textContent=t.caseSteps[i][0];el.querySelector('small').textContent=t.caseSteps[i][1]});
  const caseUnits=$('.case-result span');if(caseUnits)caseUnits.innerHTML=t.caseUnits;

  $('.business .index')?.replaceChildren(document.createTextNode(t.bizLabel));const bizH=$('.business .section-top h2');if(bizH)bizH.innerHTML=t.bizTitle;$('.business .section-note')?.replaceChildren(document.createTextNode(t.bizNote));
  $$('.business-grid article').forEach((el,i)=>{if(!t.biz[i])return;el.querySelector('p.mono').textContent=t.biz[i][0];el.querySelector('h3').innerHTML=t.biz[i][1];el.querySelector('p:last-child').textContent=t.biz[i][2]});

  $('.capabilities .index')?.replaceChildren(document.createTextNode(t.capLabel));const capH=$('.capabilities .section-top h2');if(capH)capH.innerHTML=t.capTitle;$('.capabilities .section-note')?.replaceChildren(document.createTextNode(t.capNote));
  $$('.skills article').forEach((el,i)=>{if(!t.skills[i])return;el.querySelector('h3').innerHTML=t.skills[i][0];el.querySelector('p').textContent=t.skills[i][1]});

  $('.profile .index')?.replaceChildren(document.createTextNode(t.profLabel));const profH=$('.profile-grid h2');if(profH)profH.innerHTML=t.profTitle;
  $$('.profile-data>div').forEach((el,i)=>{if(!t.profile[i])return;el.querySelector('span').textContent=t.profile[i][0];el.querySelector('b').innerHTML=t.profile[i][1]});

  $('.contact .index')?.replaceChildren(document.createTextNode(t.contactLabel));const contactH=$('.contact-copy h2');if(contactH)contactH.innerHTML=t.contactTitle;$('.contact-copy>p:not(.index)')?.replaceChildren(document.createTextNode(t.contactDesc));
  const start=$('.contact .btn.light');if(start){start.textContent=t.start;start.href=t.waHref}
  const contactCV=$('.contact .btn.darkbtn');if(contactCV)contactCV.textContent=t.contactCV;
  const cs=$$('.contact-links small');[t.email,t.phone,t.copy,t.instagram].forEach((v,i)=>{if(cs[i])cs[i].textContent=v});
  const copyText=$('#copyBtn b');if(copyText)copyText.textContent=t.copyText;
  const bizIcons=currentLang==='ja'?['スマホ','修理','カスタム']:currentLang==='en'?['PHONE','REPAIR','CUSTOM']:['HP','PERBAIKAN','CUSTOM'];
  $$('.business-grid .biz-icon').forEach((el,i)=>{if(bizIcons[i])el.textContent=bizIcons[i]});
  const visualCode=$('.visual-head span:last-child'); if(visualCode)visualCode.textContent='RM—01';
  const contactCopy=$('#copyBtn'); if(contactCopy)contactCopy.dataset.copy='+62895806296605';
  const langNames={id:'Indonesia',en:'English',ja:'日本語'};
  document.documentElement.dataset.language=currentLang;
    $('.footer-inner>span')?.replaceChildren(document.createTextNode(t.footer));$('.footer-inner>a:last-child')?.replaceChildren(document.createTextNode(t.back));

  $$('.lang-btn').forEach(b=>{const active=b.dataset.lang===currentLang;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active))});
  setTheme(root.dataset.theme||'light',false);
  if(close)closeMenu();
}
$$('.lang-btn').forEach(b=>b.addEventListener('click',()=>applyLanguage(b.dataset.lang)));
applyLanguage(currentLang,{persist:false,close:false});

// Active section navigation.
const sections=$$('main section[id]');const links=$$('.nav nav a[href^="#"]');
if('IntersectionObserver' in window){
  const sectionObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{
    if(entry.isIntersecting)links.forEach(a=>{const active=a.getAttribute('href')==='#'+entry.target.id;a.classList.toggle('active',active);if(active)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')});
  }),{rootMargin:'-35% 0px -55% 0px',threshold:0});
  sections.forEach(s=>sectionObserver.observe(s));
}
